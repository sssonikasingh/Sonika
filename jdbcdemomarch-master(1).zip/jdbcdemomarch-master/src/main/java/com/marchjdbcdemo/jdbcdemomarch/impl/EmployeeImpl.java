package com.marchjdbcdemo.jdbcdemomarch.impl;

import com.marchjdbcdemo.jdbcdemomarch.model.Employeee;
import com.marchjdbcdemo.jdbcdemomarch.repository.EmployeeInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public class EmployeeImpl implements EmployeeInterface {

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Override
    public String saveData(Employeee employee) {

        String sql="insert into employee values(?,?,?,?,?,?,?,?,?,?,?,?)";
        jdbcTemplate.update(sql,new Object[]{employee.getId(),
                employee.getEmail(),
                employee.getFirstname(),employee.getLastname(),
                employee.getPassword(),employee.getAddress(),
                employee.getDob(),employee.getCompayname(),employee.getRole(),employee.getMobile(),employee.getCity(),employee.getDeptId()});
        return "Data saved";
    }

    @Override
    public List<Employeee> getEmployees() {
        String sql="select * from employee";
        List<Employeee> list=jdbcTemplate.query(sql,new BeanPropertyRowMapper(Employeee.class));
        return list;
    }

    @Override
    public Employeee getSingleEmployee(Integer id) {

        String sql="select * from employee where id=?";
        Employeee s=jdbcTemplate.queryForObject(sql, new Object[]{id},
                new BeanPropertyRowMapper<>(Employeee.class));
        return s;
    }

    @Override
    public List<Map<String, Object>> getCombinedData() {

        String sql="select a.id, a.firstname as employeeName, b.name as deptname " +
                "from employee a,department b where b.id=a.deptId";

        List<Map<String,Object>> list=jdbcTemplate.queryForList(sql);
        return list;
    }
}
