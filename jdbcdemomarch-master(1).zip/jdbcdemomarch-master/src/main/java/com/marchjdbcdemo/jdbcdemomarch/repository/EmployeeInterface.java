package com.marchjdbcdemo.jdbcdemomarch.repository;

import com.marchjdbcdemo.jdbcdemomarch.model.Employeee;

import java.util.List;
import java.util.Map;

public interface EmployeeInterface {

    String saveData(Employeee employee);

    List<Employeee> getEmployees();

    Employeee getSingleEmployee(Integer id);

    List<Map<String,Object>>  getCombinedData();
}
