package com.marchjdbcdemo.jdbcdemomarch.controller;


import com.marchjdbcdemo.jdbcdemomarch.impl.EmployeeImpl;
import com.marchjdbcdemo.jdbcdemomarch.model.Employeee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
public class EmployeeController {

    @Autowired
    private EmployeeImpl employeeImpl;

    @PostMapping(value="/save")
    public String saveData(@RequestBody Employeee employee){

        String s= employeeImpl.saveData(employee);
        return s;
    }

    @GetMapping(value="/getemployee")
    public List<Employeee> getData(){

        List<Employeee> list= employeeImpl.getEmployees();
        return list;
    }

    @GetMapping(value="/getsingleemployee/{id}")
    public Employeee getSingleData1(@PathVariable Integer id ){

        Employeee list= employeeImpl.getSingleEmployee(id);
        return list;

    }

    @GetMapping(value="/getjoindata")
    public List<Map<String,Object>> getCombinedData1(){

        List<Map<String,Object>> list= employeeImpl.getCombinedData();
        return list;

    }

}
