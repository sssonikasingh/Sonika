package com.marchjdbcdemo.jdbcdemomarch.repository;

import com.marchjdbcdemo.jdbcdemomarch.model.Department;

public interface DeptInterface  {

    String saveDept(Department department);
}
